#!/bin/bash

# Personal Finance Tracker - System Dependencies Installer
# Automatically installs all required system dependencies

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

echo "============================================="
echo "Personal Finance Tracker - System Installer"
echo "============================================="
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "Don't run this script as root. Use a regular user with sudo privileges."
    exit 1
fi

# Check if sudo is available
if ! command -v sudo >/dev/null; then
    print_error "sudo is required but not installed."
    exit 1
fi

print_info "Starting system dependencies installation..."

# Update package lists
print_info "Updating package lists..."
sudo apt update -y

# Install core system dependencies
print_info "Installing core system dependencies..."
sudo apt install -y \
    postgresql \
    postgresql-contrib \
    nginx \
    build-essential \
    python3 \
    curl \
    wget \
    gnupg \
    lsb-release

# Install development tools
print_info "Installing development tools..."
sudo apt install -y \
    git \
    nano \
    vim \
    htop \
    unzip

# Install SSL and security tools
print_info "Installing SSL and security tools..."
sudo apt install -y \
    certbot \
    python3-certbot-nginx \
    ufw

# Install optional but recommended packages
print_info "Installing optional security packages..."
sudo apt install -y \
    fail2ban \
    logrotate

# Install Node.js 20
print_info "Installing Node.js 20..."
if ! command -v node &>/dev/null || [ "$(node --version | cut -d'v' -f2 | cut -d'.' -f1)" -lt 18 ]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
    print_info "Node.js installed: $(node --version)"
else
    print_info "Node.js is already installed: $(node --version)"
fi

# Install PM2 process manager
print_info "Installing PM2 process manager..."
if ! command -v pm2 &>/dev/null; then
    sudo npm install -g pm2
    print_info "PM2 installed: $(pm2 --version)"
else
    print_info "PM2 is already installed: $(pm2 --version)"
fi

# Enable and start services
print_info "Enabling and starting services..."
sudo systemctl enable --now postgresql
sudo systemctl enable --now nginx

# Configure firewall
print_info "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

print_info "System dependencies installation completed!"
echo ""
echo "✅ Installed packages:"
echo "   • PostgreSQL database server"
echo "   • Nginx web server"
echo "   • Node.js $(node --version)"
echo "   • PM2 process manager"
echo "   • Build tools and development utilities"
echo "   • SSL/TLS certificate tools"
echo "   • Security and monitoring tools"
echo ""
echo "🔧 Services started:"
echo "   • PostgreSQL: $(sudo systemctl is-active postgresql)"
echo "   • Nginx: $(sudo systemctl is-active nginx)"
echo "   • Firewall: $(sudo ufw status | grep Status | cut -d' ' -f2)"
echo ""
echo "🚀 Ready for application deployment!"
echo "   Run: ./setup.sh (for interactive setup)"
echo "   Or follow: MANUAL_DEPLOYMENT.md (for manual setup)"