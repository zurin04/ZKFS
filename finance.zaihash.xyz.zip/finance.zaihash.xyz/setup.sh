#!/bin/bash

# Personal Finance Tracker - Beginner-Friendly Setup Script
# This script will walk you through the deployment step by step

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }
print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Function to ask for user input
ask_input() {
    local prompt="$1"
    local default="$2"
    local result
    
    if [ -n "$default" ]; then
        read -p "$prompt [$default]: " result
        result=${result:-$default}
    else
        read -p "$prompt: " result
    fi
    
    echo "$result"
}

# Function to ask yes/no question
ask_yes_no() {
    local prompt="$1"
    local default="$2"
    local result
    
    while true; do
        if [ "$default" = "y" ]; then
            read -p "$prompt [Y/n]: " result
            result=${result:-y}
        elif [ "$default" = "n" ]; then
            read -p "$prompt [y/N]: " result
            result=${result:-n}
        else
            read -p "$prompt [y/n]: " result
        fi
        
        case $result in
            [Yy]*) return 0 ;;
            [Nn]*) return 1 ;;
            *) echo "Please answer yes or no." ;;
        esac
    done
}

# Function to pause and wait for user
pause_for_user() {
    local message="$1"
    echo ""
    echo -e "${YELLOW}$message${NC}"
    read -p "Press ENTER to continue..."
    echo ""
}

# Welcome message
clear
echo "============================================="
echo "Personal Finance Tracker - Setup Assistant"
echo "============================================="
echo ""
echo "This script will help you deploy your Personal Finance Tracker"
echo "step by step. We'll walk through each part together."
echo ""

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "Don't run this script as root. Use a regular user with sudo privileges."
    exit 1
fi

# Check if package.json exists
if [ ! -f "package.json" ]; then
    print_error "package.json not found! Please run this script from your project directory."
    exit 1
fi

pause_for_user "Ready to start? We'll begin with system checks..."

# Step 1: System checks
print_step "1. Checking your system..."

# Check memory
MEMORY_MB=$(free -m | grep '^Mem:' | awk '{print $2}')
print_info "Available memory: ${MEMORY_MB}MB"

if [ "$MEMORY_MB" -lt 1000 ]; then
    print_warning "Your system has less than 1GB RAM. The build process might be slow."
    if ! ask_yes_no "Continue anyway?"; then
        exit 1
    fi
fi

# Check if sudo is available
if ! command -v sudo >/dev/null; then
    print_error "sudo is required but not installed."
    exit 1
fi

print_info "System checks passed!"

# Step 2: Gather configuration
print_step "2. Let's configure your application..."

echo ""
echo "We need some information to set up your application:"
echo ""

# Get domain or IP
DOMAIN=$(ask_input "Enter your domain name (or press ENTER to use server IP)" "")
if [ -z "$DOMAIN" ]; then
    print_info "We'll use your server IP address instead of a domain name."
    DOMAIN="_"
fi

# Get database password
while true; do
    DB_PASSWORD=$(ask_input "Enter a secure password for your database" "")
    if [ ${#DB_PASSWORD} -lt 8 ]; then
        print_warning "Password should be at least 8 characters long."
        continue
    fi
    break
done

# Generate session secret
SESSION_SECRET=$(openssl rand -hex 32)

# Configuration
APP_NAME="personal-finance-tracker"
APP_DIR="/var/www/$APP_NAME"
DB_NAME="personal_finance_db"
DB_USER="finance_user"
APP_PORT=5000

print_info "Configuration complete!"
echo ""
echo "Your settings:"
echo "  Domain: $DOMAIN"
echo "  App Directory: $APP_DIR"
echo "  Database: $DB_NAME"
echo "  Database User: $DB_USER"
echo "  App Port: $APP_PORT"

pause_for_user "Settings look good? Let's start the installation..."

# Step 3: Update system
print_step "3. Updating your system..."

print_info "Updating package lists..."
sudo apt update -y

print_info "System updated!"

# Step 4: Install Node.js
print_step "4. Installing Node.js 20..."

if ! command -v node &>/dev/null || [ "$(node --version | cut -d'v' -f2 | cut -d'.' -f1)" -lt 18 ]; then
    print_info "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
    print_info "Node.js installed: $(node --version)"
else
    print_info "Node.js is already installed: $(node --version)"
fi

# Step 5: Install system dependencies
print_step "5. Installing system dependencies..."

print_info "Installing PostgreSQL, Nginx, and build tools..."
sudo apt install -y postgresql postgresql-contrib nginx build-essential python3 curl wget gnupg lsb-release

# Step 6: Install PM2
print_step "6. Installing PM2 process manager..."

if ! command -v pm2 &>/dev/null; then
    print_info "Installing PM2..."
    sudo npm install -g pm2
    print_info "PM2 installed: $(pm2 --version)"
else
    print_info "PM2 is already installed: $(pm2 --version)"
fi

# Step 7: Setup services
print_step "7. Starting system services..."

print_info "Starting PostgreSQL..."
sudo systemctl enable --now postgresql

print_info "Starting Nginx..."
sudo systemctl enable --now nginx

print_info "Services started!"

# Step 8: Setup database
print_step "8. Setting up your database..."

print_info "Creating database and user..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE $DB_NAME OWNER $DB_USER;
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF

print_info "Database created successfully!"

# Step 9: Setup application directory
print_step "9. Setting up application directory..."

print_info "Creating $APP_DIR..."
sudo mkdir -p $APP_DIR
sudo chown -R $USER:$USER $APP_DIR

print_info "Copying application files..."
cp -r . $APP_DIR/
cd $APP_DIR

# Clean up
rm -rf .git 2>/dev/null || true

print_info "Application files copied!"

# Step 10: Create environment file
print_step "10. Creating environment configuration..."

cat > .env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=$APP_PORT
PGHOST=localhost
PGPORT=5432
PGUSER=$DB_USER
PGPASSWORD=$DB_PASSWORD
PGDATABASE=$DB_NAME
EOF

print_info "Environment file created!"

# Step 11: Install dependencies
print_step "11. Installing application dependencies..."

print_info "This might take a few minutes..."
npm install

print_info "Dependencies installed!"

# Step 12: Setup database schema
print_step "12. Setting up database schema..."

print_info "Pushing database schema..."
npm run db:push

print_info "Database schema created!"

# Step 13: Build application
print_step "13. Building your application..."

print_info "This might take a few minutes and use more memory..."
export NODE_OPTIONS="--max-old-space-size=2048"
npm run build

if [ ! -f "dist/index.js" ]; then
    print_error "Build failed! Please check the error messages above."
    exit 1
fi

print_info "Application built successfully!"

# Step 14: Test application
print_step "14. Testing your application..."

print_info "Starting test server..."
timeout 10s node dist/index.js &
TEST_PID=$!
sleep 5

if ss -tlnp | grep -q ":$APP_PORT"; then
    print_info "Test successful! Application responds on port $APP_PORT"
    kill $TEST_PID 2>/dev/null || true
else
    print_error "Test failed! Application is not responding."
    kill $TEST_PID 2>/dev/null || true
    exit 1
fi

# Step 15: Configure PM2
print_step "15. Configuring PM2 process manager..."

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: '$APP_NAME',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: $APP_PORT,
      DATABASE_URL: 'postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: 5432,
      PGUSER: '$DB_USER',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: '$DB_NAME'
    }
  }]
};
EOF

print_info "PM2 configuration created!"

# Step 16: Configure Nginx
print_step "16. Configuring Nginx web server..."

sudo tee /etc/nginx/sites-available/$APP_NAME > /dev/null << EOF
server {
    listen 80;
    server_name $DOMAIN;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
}
EOF

# Enable site
sudo ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
if sudo nginx -t; then
    print_info "Nginx configuration is valid!"
    sudo systemctl reload nginx
else
    print_error "Nginx configuration failed!"
    exit 1
fi

# Step 17: Start application
print_step "17. Starting your application..."

print_info "Starting with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

print_info "Setting up PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

print_info "Application started!"

# Step 18: Configure firewall
print_step "18. Configuring firewall..."

print_info "Enabling firewall with web access..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

print_info "Firewall configured!"

# Step 19: Final verification
print_step "19. Final verification..."

sleep 5

# Check PM2
if pm2 list | grep -q "$APP_NAME.*online"; then
    print_info "✓ PM2 application is running"
else
    print_error "✗ PM2 application failed to start"
    pm2 logs $APP_NAME --lines 5
    exit 1
fi

# Check port
if ss -tlnp | grep -q ":$APP_PORT"; then
    print_info "✓ Application is listening on port $APP_PORT"
else
    print_error "✗ Application is not listening on port $APP_PORT"
    exit 1
fi

# Check local connectivity
if curl -s -f http://localhost:$APP_PORT >/dev/null 2>&1; then
    print_info "✓ Application responds locally"
else
    print_error "✗ Application not responding locally"
    exit 1
fi

# Check Nginx
if curl -s -f http://localhost:80 >/dev/null 2>&1; then
    print_info "✓ Nginx proxy is working"
else
    print_error "✗ Nginx proxy not working"
    exit 1
fi

# Step 20: Success!
print_step "20. Setup complete!"

# Get server IP
SERVER_IP=$(curl -s -m 5 ifconfig.me 2>/dev/null || echo "your-server-ip")

echo ""
echo "============================================="
echo "🎉 SUCCESS! Your app is now running!"
echo "============================================="
echo ""
echo "📱 Access your Personal Finance Tracker at:"
echo ""
if [ "$DOMAIN" != "_" ]; then
    echo "   🌐 http://$DOMAIN"
else
    echo "   🌐 http://$SERVER_IP"
fi
echo "   🖥️  Direct: http://$SERVER_IP:$APP_PORT"
echo ""
echo "📊 What's running:"
echo "   • Database: PostgreSQL"
echo "   • App Server: Node.js on port $APP_PORT"
echo "   • Web Server: Nginx on port 80"
echo "   • Process Manager: PM2"
echo ""
echo "🔧 Management commands:"
echo "   pm2 status                    - Check app status"
echo "   pm2 logs $APP_NAME            - View app logs"
echo "   pm2 restart $APP_NAME         - Restart app"
echo "   sudo systemctl status nginx   - Check web server"
echo ""
echo "🔒 Want HTTPS? Run this command:"
echo "   sudo apt install certbot python3-certbot-nginx"
if [ "$DOMAIN" != "_" ]; then
    echo "   sudo certbot --nginx -d $DOMAIN"
else
    echo "   sudo certbot --nginx -d your-domain.com"
fi
echo ""
echo "📋 Next steps:"
echo "   1. Open your browser and go to your app"
echo "   2. Create your first user account"
echo "   3. Start tracking your finances!"
echo ""
echo "Need help? Check MANUAL_DEPLOYMENT.md for detailed instructions."
echo ""
echo "Happy tracking! 🚀"