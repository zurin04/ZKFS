import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertGoalSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCurrency } from "@/hooks/useCurrency";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Trash2, Edit, Plus } from "lucide-react";
import { format } from "date-fns";

interface GoalsManagementProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function GoalsManagement({ isOpen, onClose }: GoalsManagementProps) {
  const [editingGoal, setEditingGoal] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { formatCurrency, getCurrencySymbol } = useCurrency();

  const { data: goals, isLoading } = useQuery({
    queryKey: ["/api/goals"],
    queryFn: () => fetch("/api/goals").then(res => res.json()),
  });

  const form = useForm({
    resolver: zodResolver(insertGoalSchema),
    defaultValues: {
      title: "",
      targetAmount: "",
      currentAmount: "0",
      deadline: format(new Date(), "yyyy-MM-dd"),
      category: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/goals", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({ title: "Goal created successfully" });
      form.reset();
      setEditingGoal(null);
    },
    onError: () => {
      toast({ title: "Failed to create goal", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest("PUT", `/api/goals/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({ title: "Goal updated successfully" });
      form.reset();
      setEditingGoal(null);
    },
    onError: () => {
      toast({ title: "Failed to update goal", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/goals/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({ title: "Goal deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete goal", variant: "destructive" });
    },
  });

  const handleSubmit = (data: any) => {
    if (editingGoal) {
      updateMutation.mutate({ id: editingGoal.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const startEdit = (goal: any) => {
    setEditingGoal(goal);
    form.reset({
      title: goal.title,
      targetAmount: goal.targetAmount,
      currentAmount: goal.currentAmount,
      deadline: goal.deadline,
      category: goal.category,
    });
  };

  const cancelEdit = () => {
    setEditingGoal(null);
    form.reset();
  };

  const getProgressPercentage = (current: string, target: string) => {
    const currentAmount = parseFloat(current);
    const targetAmount = parseFloat(target);
    return targetAmount > 0 ? Math.min((currentAmount / targetAmount) * 100, 100) : 0;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">Goals Management</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Goal Form */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">
              {editingGoal ? 'Edit Goal' : 'Create New Goal'}
            </h3>
            
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
              <div>
                <Label>Goal Title</Label>
                <Input 
                  {...form.register("title")} 
                  placeholder="e.g., Emergency Fund, Vacation Savings"
                />
              </div>

              <div>
                <Label>Category</Label>
                <Input 
                  {...form.register("category")} 
                  placeholder="e.g., Savings, Investment, Emergency"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Target Amount</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                    </div>
                    <Input
                      {...form.register("targetAmount")}
                      type="number"
                      step="0.01"
                      className="pl-8"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div>
                  <Label>Current Amount</Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 text-sm">{getCurrencySymbol()}</span>
                    </div>
                    <Input
                      {...form.register("currentAmount")}
                      type="number"
                      step="0.01"
                      className="pl-8"
                      placeholder="0.00"
                    />
                  </div>
                </div>
              </div>

              <div>
                <Label>Target Date</Label>
                <Input {...form.register("deadline")} type="date" />
              </div>

              <div className="flex space-x-3">
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {editingGoal ? 'Update Goal' : 'Create Goal'}
                </Button>
                
                {editingGoal && (
                  <Button type="button" variant="outline" onClick={cancelEdit}>
                    Cancel
                  </Button>
                )}
              </div>
            </form>
          </div>

          {/* Goals List */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Your Goals</h3>
            
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse bg-gray-200 h-20 rounded-lg"></div>
                ))}
              </div>
            ) : goals && goals.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {goals.map((goal: any) => {
                  const progressPercentage = getProgressPercentage(goal.currentAmount, goal.targetAmount);
                  const currentAmount = parseFloat(goal.currentAmount);
                  const targetAmount = parseFloat(goal.targetAmount);
                  
                  return (
                    <div key={goal.id} className="bg-gray-50 rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{goal.title}</h4>
                          <p className="text-sm text-gray-500">{goal.category}</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => startEdit(goal)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteMutation.mutate(goal.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{formatCurrency(currentAmount)} / {formatCurrency(targetAmount)}</span>
                          <span>{progressPercentage.toFixed(1)}%</span>
                        </div>
                        <Progress value={progressPercentage} className="h-2" />
                        <p className="text-xs text-gray-500">
                          Target: {format(new Date(goal.deadline), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center text-gray-500 py-8">
                No goals created yet. Start by creating your first goal!
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}