import { useState } from "react";
import NavigationHeader from "@/components/navigation-header";
import DashboardOverview from "@/components/dashboard-overview";
import CalendarView from "@/components/calendar-view";
import RecentTransactions from "@/components/recent-transactions";
import QuickAddForms from "@/components/quick-add-forms";
import TodaysTasks from "@/components/todays-tasks";
import GoalsProgress from "@/components/goals-progress";
import BillsProgress from "@/components/bills-progress";
import NotesSidebar from "@/components/notes-sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Dashboard() {
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (isMobile) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Header */}
        <header className="flex-shrink-0 z-10">
          <NavigationHeader onMenuToggle={() => setSidebarOpen(true)} />
        </header>
        
        {/* Mobile Sidebar */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="w-80 p-0">
            <NotesSidebar />
          </SheetContent>
        </Sheet>
        
        {/* Dashboard Content */}
        <main className="flex-1 p-4 overflow-y-auto">
          {/* Dashboard Overview Cards */}
          <DashboardOverview />
          
          {/* Mobile Dashboard Stack */}
          <div className="space-y-6 mt-6">
            <QuickAddForms />
            <TodaysTasks />
            <CalendarView />
            <RecentTransactions />
            <GoalsProgress />
            <BillsProgress />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-50 flex overflow-hidden" data-testid="dashboard-container">
      {/* Sidebar */}
      <aside className="w-80 bg-white border-r border-gray-200 flex flex-col flex-shrink-0">
        <NotesSidebar />
      </aside>
      
      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="flex-shrink-0 z-10">
          <NavigationHeader />
        </header>
        
        {/* Dashboard Content */}
        <section className="flex-1 p-6 overflow-y-auto">
          {/* Dashboard Overview Cards */}
          <DashboardOverview />
          
          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
            {/* Left Column */}
            <div className="lg:col-span-2 space-y-6">
              <CalendarView />
              <RecentTransactions />
            </div>
            
            {/* Right Column */}
            <div className="space-y-6">
              <QuickAddForms />
              <TodaysTasks />
              <GoalsProgress />
              <BillsProgress />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
