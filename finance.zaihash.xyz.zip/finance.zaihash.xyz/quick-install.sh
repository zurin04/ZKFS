#!/bin/bash

# Quick System Dependencies Installer
# Installs packages from system-requirements.txt

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

print_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if requirements file exists
if [ ! -f "system-requirements.txt" ]; then
    print_error "system-requirements.txt not found!"
    exit 1
fi

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    print_error "Don't run as root. Use sudo user."
    exit 1
fi

print_info "Installing system dependencies from system-requirements.txt..."

# Update package lists
sudo apt update

# Install packages from requirements file
sudo apt install -y $(grep -v '^#' system-requirements.txt | grep -v '^$' | tr '\n' ' ')

# Install Node.js 20
print_info "Installing Node.js 20..."
if ! command -v node &>/dev/null || [ "$(node --version | cut -d'v' -f2 | cut -d'.' -f1)" -lt 18 ]; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
print_info "Installing PM2..."
if ! command -v pm2 &>/dev/null; then
    sudo npm install -g pm2
fi

print_info "System dependencies installed successfully!"
echo ""
echo "✅ Ready for deployment!"
echo "   Run: ./setup.sh (interactive setup)"
echo "   Or: Follow MANUAL_DEPLOYMENT.md"