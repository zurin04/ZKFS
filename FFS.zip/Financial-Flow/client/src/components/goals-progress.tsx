import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format } from "date-fns";
import { useCurrency } from "@/hooks/useCurrency";
import GoalsManagement from "./goals-management";
import { Plus } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function GoalsProgress() {
  const { formatCurrency } = useCurrency();
  const { toast } = useToast();
  const [showGoalsModal, setShowGoalsModal] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<any>(null);
  const [addAmount, setAddAmount] = useState("");
  const [showAddMoney, setShowAddMoney] = useState(false);
  
  const { data: goals, isLoading } = useQuery({
    queryKey: ["/api/goals"],
    queryFn: () => fetch("/api/goals").then(res => res.json()),
  });

  const addMoneyToGoalMutation = useMutation({
    mutationFn: (data: { goalId: number; amount: number }) => 
      apiRequest("POST", `/api/goals/${data.goalId}/add-money`, { amount: data.amount }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/monthly-stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/daily-pnl"] });
      setShowAddMoney(false);
      setAddAmount("");
      toast({
        title: "Success",
        description: "Money added to goal successfully!",
      });
    },
    onError: (error: any) => {
      console.error("Error adding money to goal:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to add money to goal",
        variant: "destructive",
      });
    },
  });

  const handleAddMoney = () => {
    if (selectedGoal && addAmount) {
      addMoneyToGoalMutation.mutate({
        goalId: selectedGoal.id,
        amount: parseFloat(addAmount)
      });
    }
  };

  const getProgressPercentage = (current: string, target: string) => {
    const currentAmount = parseFloat(current);
    const targetAmount = parseFloat(target);
    return targetAmount > 0 ? Math.min((currentAmount / targetAmount) * 100, 100) : 0;
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 80) return "bg-success";
    if (percentage >= 50) return "bg-primary";
    if (percentage >= 30) return "bg-warning";
    return "bg-gray-400";
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sm:p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-2 bg-gray-200 rounded"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-4 sm:p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Goals Progress</h2>
          <button 
            onClick={() => setShowGoalsModal(true)}
            className="text-sm text-primary hover:text-primary-dark font-medium"
          >
            Manage
          </button>
        </div>
      </div>
      <div className="p-4 sm:p-6 space-y-4">
        {goals && goals.length > 0 ? (
          goals.map((goal: any) => {
            const progressPercentage = getProgressPercentage(goal.currentAmount, goal.targetAmount);
            const currentAmount = parseFloat(goal.currentAmount);
            const targetAmount = parseFloat(goal.targetAmount);
            
            return (
              <div key={goal.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900">{goal.title}</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">
                      {formatCurrency(currentAmount)} / {formatCurrency(targetAmount)}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSelectedGoal(goal);
                        setShowAddMoney(true);
                      }}
                      className="h-6 px-2"
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <Progress 
                  value={progressPercentage} 
                  className="w-full h-2"
                />
                <p className="text-xs text-gray-500">
                  Target: {format(new Date(goal.deadline), "MMM d, yyyy")}
                </p>
              </div>
            );
          })
        ) : (
          <div className="text-center text-gray-500 py-8">
            No goals set yet
          </div>
        )}
      </div>
      
      <GoalsManagement 
        isOpen={showGoalsModal} 
        onClose={() => setShowGoalsModal(false)} 
      />
      
      {/* Add Money Dialog */}
      <Dialog open={showAddMoney} onOpenChange={setShowAddMoney}>
        <DialogContent aria-describedby="add-money-description">
          <DialogHeader>
            <DialogTitle>Add Money to Goal</DialogTitle>
          </DialogHeader>
          <div id="add-money-description" className="sr-only">
            Add money to your selected goal and track progress
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium">Goal: {selectedGoal?.title}</p>
              <p className="text-xs text-gray-500">
                Current: {formatCurrency(parseFloat(selectedGoal?.currentAmount || "0"))} / 
                Target: {formatCurrency(parseFloat(selectedGoal?.targetAmount || "0"))}
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Amount to Add</label>
              <Input
                type="number"
                value={addAmount}
                onChange={(e) => setAddAmount(e.target.value)}
                placeholder="Enter amount"
                min="0"
                step="0.01"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleAddMoney}
                disabled={!addAmount || addMoneyToGoalMutation.isPending}
                className="flex-1"
              >
                {addMoneyToGoalMutation.isPending ? "Adding..." : "Add Money"}
              </Button>
              <Button variant="outline" onClick={() => setShowAddMoney(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
