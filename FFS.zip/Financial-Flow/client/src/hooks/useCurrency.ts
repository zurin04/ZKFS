import { useAuth } from "@/hooks/useAuth";

export function useCurrency() {
  const { user } = useAuth();
  const currency = user?.currency || "USD";

  const formatCurrency = (amount: number | string): string => {
    const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;
    
    if (isNaN(numAmount)) return "0.00";

    if (currency === "PHP") {
      return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        minimumFractionDigits: 2,
      }).format(numAmount);
    } else {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 2,
      }).format(numAmount);
    }
  };

  const getCurrencySymbol = (): string => {
    return currency === "PHP" ? "₱" : "$";
  };

  const getCurrencyCode = (): string => {
    return currency;
  };

  return {
    currency,
    formatCurrency,
    getCurrencySymbol,
    getCurrencyCode,
  };
}